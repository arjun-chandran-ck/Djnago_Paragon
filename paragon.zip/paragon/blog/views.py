from django.shortcuts import render, get_object_or_404,redirect
from .models import *
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User, auth
from django.http import HttpResponseRedirect,HttpResponse,Http404
from django.urls import reverse
from django.contrib import messages
from .forms import *
from django.urls import reverse_lazy
from django.forms import ModelForm
from django.core.mail import send_mail
from django.contrib.auth.decorators import user_passes_test
from django.conf import settings

from django.views.generic import (DetailView, ListView, FormView, CreateView, UpdateView, DeleteView)
import datetime
from django.core.mail import send_mail


# Create your views here.



items_clt = Menuitem.objects.filter(location='Calicut')
items_madrid = Menuitem.objects.filter(location='Madrid')
items_dubai = Menuitem.objects.filter(location='Dubai')
items_london = Menuitem.objects.filter(location='London')

# filtering logged in user to check if its among the admin users
def email_check(user):
    return user.username.endswith('@paragon.com')

adminusers =["paragonadmin@paragon.com","dubaiadmin@paragon.com", "londonadmin@paragon.com","madridadmin@paragon.com","calicutadmin@paragon.com"]


madrid_dict =  {'madrid_no':'+1 5589 55488 55',
                'items':items_madrid,
                'admins':adminusers     
              }

london_dict =  {'london_no':'+44 20 7234 3456',
                'items':items_london,
                'admins':adminusers   
              }

clt_dict =  {'clt_no':'+91 99 99 09 90 90',
                'items':items_clt,
                'admins':adminusers,
                             }

dubai_dict = {'dubai_no':'+971 4 33 58700',
              'items':items_dubai,
              'admins':adminusers,
               }
# home pages for each location
def index(request):
    if request.method=='POST':
        product =request.POST.get('productid')
        remove= request.POST.get('remove')
        increment= request.POST.get('increment')
        cart= request.session.get('cart')
        user= request.POST.get('username')
      
        if user is not None and user !="":
            if cart:
            
                quantinty = cart.get(product)
                if quantinty:
                    if increment:
                        cart[product] =quantinty+1
                    elif remove:
                        cart[product] =quantinty-1
                    else:
                        cart[product] =quantinty+1
                else:
                    cart[product] =1
            else:
                cart ={}
                cart[product] =1
            request.session['cart']=cart
            print("Cart:  ", request.session['cart'])
            return redirect("/")
        else:
            request.session['cart']=None
            return redirect('/login')
    else:
        items_clt = Menuitem.objects.filter(location='Calicut')
        clt_dict =  {'clt_no':'+91 99 99 09 90 90',
                'items':items_clt,
                'admins':adminusers,
                             }
        return render(request,'index.html',clt_dict)
    
                
def dubai(request):
 
    if request.method=='POST':
        product =request.POST.get('productid')
        remove= request.POST.get('remove')
        increment= request.POST.get('increment')
        user= request.POST.get('username')
        cartd= request.session.get('cartd')
        if user is not None and user !="":
            if cartd:
                quantinty = cartd.get(product)
                if quantinty:
                    if increment:
                        cartd[product] =quantinty+1
                    elif remove:
                        cartd[product] =quantinty-1
                    else:
                        cartd[product] =quantinty+1
                else:
                    cartd[product] =1
            else:
                cartd ={}
                cartd[product] =1
            request.session['cartd']=cartd
            print("Cart:  ", request.session['cartd'])
            return redirect("/dubai")
        else:
            request.session['cartd']=None
            return redirect('/login')
    else:
        items_dubai = Menuitem.objects.filter(location='Dubai')
        dubai_dict = {'dubai_no':'+971 4 33 58700',
              'items':items_dubai,
              'admins':adminusers,
               }
        return render(request,'dubai.html',dubai_dict)
    
def madrid(request):
    if request.method=='POST':
        product =request.POST.get('productid')
        remove= request.POST.get('remove')
        increment= request.POST.get('increment')
        user= request.POST.get('username')
        cartm= request.session.get('cartm')
        print("UUUUUUUUUUUUUUUUU",user)
        if user is not None and user !="":
            if cartm:
                quantinty = cartm.get(product)
                if quantinty:
                    if increment:
                        cartm[product] =quantinty+1
                    elif remove:
                        cartm[product] =quantinty-1
                    else:
                        cartm[product] =quantinty+1
                else:
                    cartm[product] =1
            else:
                cartm ={}
                cartm[product] =1
            request.session['cartm']=cartm
            print("Cart:  ", request.session['cartm'])
            return redirect("/madrid")
        else:
            request.session['cartm']=None
            return redirect('/login')
    else:
        items_madrid = Menuitem.objects.filter(location='Madrid')
        madrid_dict =  {'madrid_no':'+1 5589 55488 55',
                'items':items_madrid,
                'admins':adminusers     
              }
        return render(request,'madrid.html',madrid_dict)

def london(request):
    if request.method=='POST':
        product =request.POST.get('productid')
        remove= request.POST.get('remove')
        increment= request.POST.get('increment')
        cartl= request.session.get('cartl')
        user= request.POST.get('username')
      
        if user is not None and user !="":
            if cartl:
                quantinty = cartl.get(product)
                if quantinty:
                    if increment:
                        cartl[product] =quantinty+1
                    elif remove:
                        cartl[product] =quantinty-1
                    else:
                        cartl[product] =quantinty+1
                else:
                    cartl[product] =1
            else:
                cartl ={}
                cartl[product] =1
            request.session['cartl']=cartl
            print("Cart:  ", request.session['cartl'])
            return redirect("/london")
        else:
            request.session['cartl']=None
            return redirect('/login')
    else:
        items_london = Menuitem.objects.filter(location='London')
        london_dict =  {'london_no':'+44 20 7234 3456',
                'items':items_london,
                'admins':adminusers   
              }
        return render(request,'london.html',london_dict)
    


# About page
def about(request):
    return render(request, 'about.html', {})

# Contact form for a user
def contact(request):
    if request.method == "POST":
        name= request.POST.get("name")
        email = request.POST.get("email")
        subject = request.POST.get("subject")
        message = request.POST.get("message")
        
        message1 = Contact.objects.create(
            name = name,
            email= email,
            subject = subject,
            message = message,
        )
        subject ="Contact Message: "+subject
        message1.save()
        send_mail(
        subject,
        message+f"\n\n\n Contact MSSAGE FROM:{name}\n EMAIL: {email}",
        'mailpython20@gmail.com',
        ['mailpython20@gmail.com'],
        fail_silently=False,
        )
        return render(request, 'contact.html', {'msg':'Your message has been sucessfully sent. Thankyou for the Feedback!'})
    else:
        return render(request, 'contact.html', {})

def login(request):
    if request.method == "POST":
        email = request.POST.get('email')
        print(email)
        password = request.POST.get('password')
        print(password)

        user = authenticate(username=email, password=password)
        if user is not None:
            auth.login(request, user)
            #adminusers =["dubaiadmin@paragon.com", "londondmin@paragon.com","madridadmin@paragon.com"]
            for adms in adminusers:
                if user.username==adms:
                    return redirect("/addfoods")
                    break  
            return redirect("/")
        else:
            messages.info(request, 'Login Failed !   Pls enter valid Credentials.')
            return redirect('login')
            #return render(request, 'login.html',{'msg':})
    else:
        return render(request, 'login.html',{})

def logout(request):
    auth.logout(request)
    return redirect("/")

def register(request):
    
    if request.method == "POST":
        name = request.POST.get('name')
        print(name)
        email = request.POST.get('email')
        print(email)
        password = request.POST.get('password')
        print(password)
        mobile = request.POST.get('mobile')
        print(mobile)

        user1 = Register.objects.filter(email=email).exists()
        if not user1:
            usernew = User.objects.create_user(
                username=email,
                password=password,
            )
            userpro = Register.objects.create(
                user=usernew,
                name=name,
                email=email,
                password=password,
                mobile=mobile,
            )
            userpro.save()
            messages.info(request,'User Registration Sucessfull!  Please Login to continue.')
            return redirect('login')
            
        else:
            messages.info(request,'User already existing. Pls try again.')
            return redirect('register')
    else:
        return render(request, 'register.html', {})

# to book a table in any of four Locations 
@login_required(login_url="/login")
def booktable(request):
    if request.method == 'POST':
        email = request.POST.get('email')    
        date = request.POST.get('date')
        time = request.POST.get('time')
        nos = request.POST.get('people')
        location = request.POST.get('location')   
        booking = Booktable.objects.create(
            email= email,
            date = date,
            time=time,
            nos=nos,
            location=location,
        )
        booking.save()
        message = f"Hello {email},\n\nThankyou for Your Booking. Your Booking has been confirmed. :\n\n Date: {date} \n Time: {time} \n No of People: {nos} \n Location: {location}"
        message = message+"\n\n\n Greting from Paragon International."       
        #messagex = f"Hello {message}, \n\n Your Order for items {item_name} \n is Confirmed."
        send_mail(
        f'Paragon International: Your Booking is Confirmed dated {datetime.date.today()}',
        message,
        'mailpython20@gmail.com',
        [email],
        fail_silently=False,
        )
        return render(request, 'booktable.html', {'msg':f'Your booking was Successfull. Details are sent to {email}.','admins':adminusers})
    else:
        return render(request, 'booktable.html', {})

# display the table booking history details by a registered user.
@login_required(login_url="/login")
def booking_details(request, username):
    bookings=Booktable.objects.filter(email=username)
    for x in bookings:
        if x.email is not None:
            return render(request, 'booking.html',{'booking':bookings})
    messages.info(request,"No Bookings found for your account")
    return render(request, 'booking.html')        

# to cancel a table booking by user.
@login_required(login_url="/login")
def deletebooking(request, email):
    if request.method=="POST":
        pi=Booktable.objects.get(email=email)
        pi.delete()
        messages.info(request,"Your Booking cancelled sucessfully")
        return render(request, 'booking.html')
        #return HttpResponseRedirect("/addfoods#foodtables",{})
    else:
        return render(request, 'booking.html', {})


# add new food items by registered admin users only
@login_required(login_url="/login")
@user_passes_test(email_check,login_url='/login/')
def addfoods(request):
    foods = Menuitem.objects.all()
    #foods= [dubaifoods, madridfoods, londonfoods,cltfoods]
    if request.method=="POST":
        location = request.POST.get('location')
        name = request.POST.get('name')
        img = request.FILES["img"]
        desc = request.POST.get('desc')
        currency = request.POST.get('currency')
        price = request.POST.get('price')
        category = request.POST.get('category') 
        price = float(price)
        fooduser = Menuitem.objects.create(
                name=name,
                location=location,
                img=img,
                desc=desc,
                currency=currency,
                price=price,
                category=category,
            )
        fooduser.save()
        messages.info(request,"Food added sucessfully")
        return redirect('/addfoods')
        #return render(request,"addfoods.html", {"msg":"Food added sucessfully",'foods':foods})
    else:
        return render(request, 'addfoods.html', {'foods':foods})

# delete food items by registered admin users only
@login_required(login_url="/login")
@user_passes_test(email_check,login_url='/login/')
def deletefood(request, id):
    if request.method=="POST":
        pi=Menuitem.objects.get(pk=id)
        pi.delete()
        messages.info(request,"The food item deleted sucessfully")
        return redirect('/addfoods#foodtables')
        #return HttpResponseRedirect("/addfoods#foodtables",{})
    else:
        return render(request, 'addfoods.html', {})

# update food items by registered admin users only
@login_required(login_url="/login")
@user_passes_test(email_check,login_url='/login/')
def updatefood(request, id):
    if request.method=="POST":
        pi=Menuitem.objects.get(pk=id)
        name = request.POST.get('name')
        desc = request.POST.get('desc')
        currency = request.POST.get('currency')
        price = request.POST.get('price')
        category = request.POST.get('category') 
        price = float(price)
        fooduser = Menuitem.objects.filter(pk=id).update(
                name=name,
                desc=desc,
                currency=currency,
                price=price,
                category=category,
            )
        messages.info(request,"Food items updated sucessfully")
        return redirect('/addfoods#foodtables')
        #return HttpResponseRedirect("/addfoods#foodtables",{})
        
    else:
        pi=Menuitem.objects.get(pk=id)
        
        return render(request,"update.html", {'item':pi}) 

# to display the cart items created by a login session of a user in CALICUT location.
@login_required(login_url="/login")
def cartitems(request):
    cart = request.session.get('cart')
    if cart:
        ids = list(request.session.get('cart').keys())
        c= Menuitem.objects.filter(id__in=ids)
        print(cart)
        return render(request,"cartitems.html", {'items':c})
    else:
        return render(request,"cartitems.html",{})
    
# to display the cart items created by a login session of a user in DUBAI location.
@login_required(login_url="/login")
def cartitemsdub(request):
    cartd = request.session.get('cartd')
    if cartd:
        ids = list(request.session.get('cartd').keys())
        c= Menuitem.objects.filter(id__in=ids)
        print(c)
        return render(request,"cartitemsdub.html", {'items':c})
    else:
        return render(request,"cartitemsdub.html",{})

# to display the cart items created by a login session of a user in MADRID location.              
@login_required(login_url="/login")
def cartitemsmad(request):
    cartm = request.session.get('cartm')
    if cartm:
        ids = list(request.session.get('cartm').keys())
        c= Menuitem.objects.filter(id__in=ids)
        return render(request,"cartitemsmad.html", {'items':c})
    else:
        return render(request,"cartitemsmad.html",{})

# to display the cart items created by a login session of a user in LONDON location.  
@login_required(login_url="/login")
def cartitemslon(request):
    cartl = request.session.get('cartl')
    if cartl:
        ids = list(request.session.get('cartl').keys())
        c= Menuitem.objects.filter(id__in=ids)
        return render(request,"cartitemslon.html", {'items':c})
    else:
        return render(request,"cartitemslon.html",{})

# checkout display for cart items    
@login_required(login_url="/login")    
def checkout(request, location):
    if request.method=='POST':
        name= request.POST.get('name')
        email= request.POST.get('email')
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        location = location
        products=[]
        item_name=[]
        item=[]
        if location=="Calicut":
            cart = request.session.get('cart')
        elif location=="Dubai":
            cart = request.session.get('cartd')
        elif location=="London":
            cart = request.session.get('cartl')
        elif location=="Madrid":
            cart = request.session.get('cartm')
        for i in cart.keys():
            products= Menuitem.objects.filter(pk=i)
            for product in products:
                order = Orders.objects.create(
                    name= name,
                    address=address,
                    email=email,
                    phone=phone,
                    location = location,
                    productid= product.id,
                    productname = product.name,
                    currency = product.currency,
                    price = product.price,
                    quantity= cart[str(product.id)],
                    total = cart[str(product.id)]*product.price,
                    date = datetime.datetime.now()
                )
                order.save()
                item_name.append("Item Name :"+product.name)
                item_name.append("Price: "+str(product.price)+" "+product.currency)
                item_name.append("Quantity: "+str(cart[str(product.id)]))
                item_name.append("Total: "+str(cart[str(product.id)]*product.price)+" "+product.currency)
            item_name.append("\n")  
        message = f"Hello {name},\n\nThankyou for Your Order. The Order for following items have been confirmed. :\n\n"
        for i in item_name:
            message+=i+"\n"
        message = message+f"Delivery Address: \n{address} \nPhone: {phone} \nDate Ordered: {datetime.datetime.now()}\n"
        message = message+"\n\n\n Greting from Paragon International.\nParagon International \nKNR Road \nCH Over Bridge \nCLT 673001\nPhone:\nEmail: prggroups@prg.com \n\nThis is an auto-generated mail.Kinldy donot reply to this email."       
       
        send_mail(
        f'Paragon International: Your Order is Confirmed dated {datetime.date.today()}',
        message,
        'mailpython20@gmail.com',
        [email],
        fail_silently=False,
        )
        msg= "Your Order Placed Sucessfully"
        if location=="Calicut":
            messages.info(request,msg)
            request.session['cart']={}
            return redirect('/')
            
          
        elif location=="Dubai":
            messages.info(request,msg)
            request.session['cartd']={}
            return redirect('dubai')
            
        elif location=="London":
            messages.info(request,msg)
            request.session['cartl']={}
            return redirect('london')
            
        elif location=="Madrid":
            messages.info(request,msg)
            request.session['cartm']={}
            return redirect('madrid')
            
    else:
        return render(request, 'checkout.html',{})

# display the order history details by a registered user.
@login_required(login_url="/login")
def order_details(request, username):
    if username is not None:
        print(username)
        orders= Orders.objects.filter(email=username)
        print(orders)
        if orders is not None:
            return render(request, 'orders.html', {'orders':orders})
        else:
            messages.info(request,"No Orders found for your account")
            return redirect('orders.html')
    else:
        return render(request, 'index.html', clt_dict)

# to change the password of a user
@login_required(login_url="/login")
def changepassword(request, username):
    if request.method=='POST':
        user= User.objects.get(username=username)
        currentpassword = request.POST.get('currentpassword')
        newpassword = request.POST.get('newpassword')
        confirmpassword = request.POST.get('confirmpassword')
        if newpassword==confirmpassword:
            user.set_password(newpassword)
            user.save()
            messages.info(request,'Password changed sucessfully')
            return redirect(request,'changepassword')
        else:
            messges.info(request, 'Password mismatch')
            return redirect('changepassword')
            
    else:
        return render(request, 'changepassword.html',{} )  
