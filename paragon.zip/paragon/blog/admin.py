from django.contrib import admin
from django.contrib.admin.decorators import register
from .models import *

# Register your models here.
admin.site.register(Register)
admin.site.register(Contact)
admin.site.register(Booktable)
admin.site.register(Menuitem)
admin.site.register(Orders)


