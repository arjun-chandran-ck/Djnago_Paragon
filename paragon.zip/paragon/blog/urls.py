from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',views.index, name="index"),
    path('about/', views.about, name="about"),
    path('dubai/', views.dubai, name="dubai"),
    path('madrid/', views.madrid, name="madrid"),
    path('london/', views.london, name="london"),
    path('register/', views.register, name="register"),
    path('contact/', views.contact, name="contact"),
    path('login/', views.login, name="login"),
    path('logout/', views.logout, name="logout"),
    path('booktable/', views.booktable, name="booktable"),
    path('addfoods/', views.addfoods, name="addfoods"),
    path('deletefood/<int:id>/', views.deletefood, name="deletefood"),
    path('updatefood<int:id>/', views.updatefood, name="updatefood"),
    path('cartitems/', views.cartitems, name="cartitems"),
    path('cartitemsdub/', views.cartitemsdub, name="cartitemsdub"),
    path('cartitemslon/', views.cartitemslon, name="cartitemslon"),
    path('cartitemsmad/', views.cartitemsmad, name="cartitemsmad"),
    path('checkout/<str:location>/', views.checkout, name="checkout"),
    path('order_details/<str:username>/', views.order_details, name="order_details"),
    path('booking_details/<str:username>/', views.booking_details, name="booking_details"),
    path('changepassword/<str:username>/', views.changepassword, name="changepassword"),
    path('deletebooking/<str:email>/', views.deletebooking, name="deletebooking"),


           
   

]
