from django import template
register = template.Library()


# filter to check if a product is already added to cart
# used in menu item html page for increasin or decreasing the cart quantity if item already exist in cart
# otherwise set quatitny to 1 in cart
@register.filter(name='is_in_cart')
def is_in_cart(product, cart):
    if cart is not None:
        cart_keys = cart.keys()
        for i in cart_keys:
            if int(i) ==product.id:
                return True
        return False
    else:
        return False

@register.filter(name='cart_qty')
def cart_qty(product, cart):
    cart_keys = cart.keys()
    for i in cart_keys:
        if int(i) ==product.id:
            return int(cart[i])
    return 0

@register.filter(name='cart_total')
def cart_total(product, cart):
   return (round(product.price*float(cart_qty(product,cart)),2))

@register.filter(name='cart_amt')
def cart_amt(product, cart):
    sum=0
    for p in product:
        sum+=cart_total(p,cart)
    return round(sum,2)

# filter to return the currency by checking the location from foods table.
# used in cartitems function to display currency.   
@register.filter(name='currency')
def currency(product):
    for p in product:
        currency = p.currency
    return currency

# filter to return the location by checking the location from foods table.
# used in cartitems function to clear the cart session of location after checkout.
@register.filter(name='location')
def location(product):
    for p in product:
        location = p.location
    return location

# filter to check if there is any item in the cart of current session.
@register.filter(name='check_cart')
def check_cart(cart):
    flag= True
    cart_values = cart.values()
    for i in cart_values:
        if i!=0:
            flag= False
            break
    return flag

# filters the food items [for update/delete] for respective admins logged in from each location.   
@register.filter(name='foodfilter')
def foodfilter(username):
    adminusers ={"dubaiadmin@paragon.com":"Dubai", 
                 "londonadmin@paragon.com":"London",
                "madridadmin@paragon.com":"Madrid",
                "calicutadmin@paragon.com":"Calicut",
                "paragonadmin@paragon.com":["Calicut","Dubai","London","Madrid"]
                }
    for i,m in adminusers.items():
        if i in username:
            return m

