from django.db import models
from django.conf import settings
from django.contrib.auth.models import User


# Create your models here.
class Register(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=20)
    email = models.EmailField()
    password = models.CharField(max_length=20)
    mobile = models.CharField(max_length=20)

    def __str__(self):
        return str(self.user.username)

class Contact(models.Model):
    name = models.CharField(max_length=20)
    email = models.EmailField()
    subject = models.CharField(max_length=20)
    message = models.CharField(max_length=40)

    def __str__(self):
        return str(self.name)

class Booktable(models.Model):
    email = models.EmailField()
    date = models.DateField()
    time = models.TimeField()
    nos = models.CharField(max_length=20)
    location = models.CharField(max_length=20, null=True)
   

    def __str__(self):
        return str(self.date)


class Menuitem(models.Model):
    name= models.CharField(max_length=20)
    location= models.CharField(max_length=20,default="NIL")
    img= models.ImageField(null=True, blank=True, upload_to='cltpics/')
    desc= models.CharField(max_length=20)
    currency= models.CharField(max_length=20)
    price= models.FloatField()
    category= models.CharField(max_length=20)

    def __str__(self):
        return str(self.name)


class Orders(models.Model):
    name= models.CharField(max_length=20)
    address= models.CharField(max_length=100,null=True)
    phone= models.CharField(max_length=12,null=True)
    email = models.EmailField(null=True)
    location= models.CharField(max_length=20,default="NIL")
    productid = models.IntegerField()
    productname = models.CharField(max_length=20)
    currency= models.CharField(max_length=20)
    price= models.FloatField()
    quantity = models.FloatField()
    total= models.FloatField()
    date = models.DateTimeField()

    def __str__(self):
        return str(self.name)

